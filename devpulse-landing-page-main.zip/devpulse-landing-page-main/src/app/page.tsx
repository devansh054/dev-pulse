import { HomeClient } from "./_components/HomeClient";

export default function HomePage() {
  return <HomeClient />;
}